/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pidev;

import Entities.Annonces;
import Entities.Sponsors;
import Services.ServicesAnnonces;
import Services.ServicesSponsors;

/**
 *
 * @author Malek Guemri
 */
public class PIDEV {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Annonces a1 = new Annonces(1,"adresse1","type1","annonce1");
        Annonces a2 = new Annonces(2,"adresse2","type2","annonce2");
        Sponsors s1 = new Sponsors(1,"event1","nom1");
        Sponsors s2 = new Sponsors(2,"event2","nom2");
        
        ServicesAnnonces sa = new ServicesAnnonces();
        ServicesSponsors sp = new ServicesSponsors();
        
        sa.ajouterAnnonce(a1);
        sa.ajouterAnnonce(a2);
        sa.afficherAnnonce();
    }
    
}
