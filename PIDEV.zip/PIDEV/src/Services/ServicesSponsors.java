/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Entities.Sponsors;
import Utils.ConnexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Malek Guemri
 */
public class ServicesSponsors {
    Connection c = ConnexionDB.getInstance().getConnection();
    
    public void ajouterSponsors(Sponsors s)
    {
        try {
            Statement st=c.createStatement();
            String req="insert into sponsors values("+s.getIDsponsors()+",'"+s.getEvent()+"','"+s.getNom()+"')";
            
            st.executeUpdate(req);
        } catch (SQLException ex) {
            Logger.getLogger(ServicesSponsors.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     public void modifierSponsors(Sponsors s, String Event, String Nom){
       
        try {
            
            PreparedStatement pst = c.prepareStatement("update sponsors set event=?, nom=? where IDsponsors=?");
            pst.setString(1,Event);
            pst.setString(2,Nom);
            pst.setInt(3,s.getIDsponsors());
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ServicesAnnonces.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     public void afficherSponsors(){
        PreparedStatement ps;
        try {
            ps = c.prepareStatement("select * from sponsors");

        ResultSet rs = ps.executeQuery();

        while (rs.next()){
            System.out.println("Sponsor ID : "+rs.getInt(1)+" , Event :"+rs.getString(2)+" , Type :"+rs.getString(3));
        }
        } catch (SQLException ex) {
            Logger.getLogger(ServicesAnnonces.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void supprimerSponsors(Sponsors s){

        try {
        PreparedStatement pt = c.prepareStatement("delete from sponsors where IDsponsors =?");
        pt.setInt(1,s.getIDsponsors());
            pt.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ServicesAnnonces.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
