/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Entities.Annonces;
import Utils.ConnexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Malek Guemri
 */
public class ServicesAnnonces {
     Connection c = ConnexionDB.getInstance().getConnection();
     
     public void ajouterAnnonce(Annonces a)
    {
        try {
            Statement st=c.createStatement();
            String req="insert into annonce values("+a.getIDannonce()+",'"+a.getAdresse()+"','"+a.getType()+"','"+a.getDescription()+"')";
            
            st.executeUpdate(req);
        } catch (SQLException ex) {
            Logger.getLogger(ServicesAnnonces.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     public void modifierAnnonce(Annonces a, String Adresse, String type, String Description){
       
        try {
            
            PreparedStatement pst = c.prepareStatement("update annonce set adresse=?, type=?, description=? where idannonce=?");
            pst.setString(1,Adresse);
            pst.setString(2,type);
            pst.setString(3,Description);
            pst.setInt(4,a.getIDannonce());
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ServicesAnnonces.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     public void afficherAnnonce(){
        PreparedStatement pt;
        try {
            pt = c.prepareStatement("select * from annonce");

        ResultSet rs = pt.executeQuery();

        while (rs.next()){
            System.out.println("ID : "+rs.getInt(1)+" , Adresse :"+rs.getString(2)+" , Type :"+rs.getString(3)+ " ,Description:"+rs.getString(4));
        }
        } catch (SQLException ex) {
            Logger.getLogger(ServicesAnnonces.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void supprimerAnnonce(Annonces a){

        try {
        PreparedStatement pt = c.prepareStatement("delete from annonce where IDannonce =?");
        pt.setInt(1,a.getIDannonce());
            pt.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ServicesAnnonces.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
