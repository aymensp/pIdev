/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author Malek Guemri
 */
public class Sponsors {
    private int IDsponsors;
    private String event;
    private String nom;

    @Override
    public String toString() {
        return "Sponsors{" + "IDsponsors=" + IDsponsors + ", event=" + event + ", nom=" + nom + '}';
    }

    public void setIDsponsors(int IDsponsors) {
        this.IDsponsors = IDsponsors;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getIDsponsors() {
        return IDsponsors;
    }

    public String getEvent() {
        return event;
    }

    public String getNom() {
        return nom;
    }

    public Sponsors(int IDsponsors, String event, String nom) {
        this.IDsponsors = IDsponsors;
        this.event = event;
        this.nom = nom;
    }
}
