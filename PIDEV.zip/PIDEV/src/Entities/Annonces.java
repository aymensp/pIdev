/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author Malek Guemri
 */
public class Annonces {
    private int IDannonce;
    private String adresse;
    private String type;
    private String description;

    public Annonces(int IDannonce, String adresse, String type, String description) {
        this.IDannonce = IDannonce;
        this.adresse = adresse;
        this.type = type;
        this.description = description;
    }

    public int getIDannonce() {
        return IDannonce;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    public void setIDannonce(int IDannonce) {
        this.IDannonce = IDannonce;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Annonces{" + "IDannonce=" + IDannonce + ", adresse=" + adresse + ", type=" + type + ", description=" + description + '}';
    }
    
}
