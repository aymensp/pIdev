/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Entities.Utilisateur;
import Utils.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author AMINE
 */
public class ServiceUtilisateur {

   private Statement ste;
   
   Connection con = DataBase.getInstance().getConnection();
  
public void Ajouter (Utilisateur p)
    {
        
        String req ="INSERT INTO utilisateur VALUES ("+ p.getId() +"','"+ p.getNom() + "', '" + p.getPrenom() + "', '" + p.getEmail() + "', '" + p.getPassword() + "', '" + p.getAge() + "', '" + p.getNumero() + "', '" + p.getSexe() +");"; 
         try{
            PreparedStatement ste = con.prepareStatement(req) ;
            ste.setInt(1,p.getId());
            ste.setString(2,p.getNom()); 
            ste.setString(3,p.getPrenom());
            ste.setString(4,p.getEmail()); 
            ste.setString(5,p.getPassword()) ; 
            ste.setInt(6,p.getAge());
            ste.setInt(7,p.getNumero()) ; 
            ste.setString(8,p.getSexe()) ; 
            ;
            
           
            
              ste.executeUpdate() ; 
            } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
        
        }
public ObservableList<Utilisateur> getAll(){
        String req="SELECT * FROM utilisateur" ;
        ObservableList<Utilisateur> list = FXCollections.observableArrayList();
        try 
        {
        
            PreparedStatement ste = con.prepareStatement(req) ;
            ResultSet rs = ste.executeQuery(); 
            while (rs.next())
            {
                int id = rs.getInt(1);
                String nom = rs.getString(2);
                String prenom = rs.getString(3);
                String email = rs.getString(4);
                String password = rs.getString(5);
                int age = rs.getInt(6);
                int numero = rs.getInt(7);
                String sexe = rs.getString(8);
                
                
                Utilisateur p= new Utilisateur (nom, prenom, email, password,sexe,numero,age,id);
                
            }
        
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return list;
    }
 public void DeleteUtil (int id )
    {
    String req="DELETE  from utilisateur where  id =?" ; 
        try { 
            PreparedStatement ste = con.prepareStatement(req) ;
             
            
            ste.setInt(1,id) ;
            ste.executeUpdate() ; 
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }
       
    public Utilisateur rechercher(int id)
    {
  
        String req="SELECT * FROM utilisateur where id=?" ;
        try 
        { 
            PreparedStatement ste = con.prepareStatement(req) ;
            ste.setInt(1, id);
            ResultSet rs = ste.executeQuery(); 
            while (rs.next())
            {
                
                String nom = rs.getString(1);
                String prenom = rs.getString(2);
                String email = rs.getString(3);
                String password = rs.getString(4);
                int age = rs.getInt(5);
                int numero = rs.getInt(6);
                String sexe = rs.getString(7);
                Utilisateur p = new Utilisateur(nom, prenom, email, password,sexe,numero,age,id);
                return p;
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return null;
    }
    public void updateUtilisateur (Utilisateur p, int id )
    {
    String req="UPDATE utilisateur SET nom=?,prenom=?, email=?, password=?,age=?,numero=?,sexe=? WHERE id =?" ; 
        try { 
            PreparedStatement ste = con.prepareStatement(req) ;
             
            ste.setString(1,p.getNom()); 
            ste.setString(2,p.getPrenom());
            ste.setString(3,p.getEmail()); 
            ste.setString(4,p.getPassword()) ;
            ste.setInt(5,p.getAge());
            ste.setInt(6,p.getNumero()) ; 
            ste.setString(7,p.getSexe()) ; 
            
                        
            ste.executeUpdate() ; 
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    
    }
}
