/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author AMINE
 */
public interface ICampService {
    void ajouter(Entities.Camp c) throws SQLException;
    boolean delete(Entities.Camp c) throws SQLException;
    boolean update(Entities.Camp c) throws SQLException;
    List<Entities.Camp> readAll() throws SQLException;
}

    

