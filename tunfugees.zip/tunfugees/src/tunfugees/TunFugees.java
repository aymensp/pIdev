/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tunfugees;

import Entities.Utilisateur;
import Services.ServiceUtilisateur;
import java.util.List;

/**
 *
 * @author AMINE
 */
public class TunFugees {
    
    public static void main(String[] args) {
        ServiceUtilisateur ser = new ServiceUtilisateur();
        
        Utilisateur p1 = new Utilisateur("hssan", "ben mohssen","kjbib@khb.tn","561651","male",515151551, 10,16);
        Utilisateur p2 = new Utilisateur("hassna", "ben hassniya","kjbib@khb.tn","561651","male",515151551, 10,10);
        
        //
        ser.Ajouter(p2);
        ser.Ajouter(p1);
        List<Utilisateur> list = ser.getAll();
        System.out.println(list);
    }
    
}
