/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author AMINE
 */
public class Utilisateur {
    private String nom;
    private String prenom;
    private String email;
    private String password;
    private String sexe;
    private int numero;
    private int age ;
    private int id;

    @Override
    public String toString() {
        return "Utilisateur{" + "nom=" + nom + ", prenom=" + prenom + ", email=" + email + ", password=" + password + ", sexe=" + sexe + ", numero=" + numero + ", age=" + age + ", id=" + id + '}';
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getSexe() {
        return sexe;
    }

    public int getNumero() {
        return numero;
    }

    public int getAge() {
        return age;
    }

    public int getId() {
        return id;
    }

    public Utilisateur(String nom, String prenom, String email, String password, String sexe, int numero, int age, int id) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.password = password;
        this.sexe = sexe;
        this.numero = numero;
        this.age = age;
        this.id = id;
    }
}
