/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tunfugees.userservices;

import Tunfugees.userentites.Camp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import javafx.collections.FXCollections;
import Tunfugees.utile.ConnexionBD;
/**
 *
 * @author AMINE
 */
public class ServiceCamp {
    
private Statement ste;
    
    Connection cnx= ConnexionBD.getInstance().getCnx();

    
   public void  ajouter(Camp c) throws SQLException {
        ste = cnx.createStatement();
        String requeteInsert = "INSERT INTO `camp` (`idCamp`, `nomCamp`, `nbrmax`, `nombreRef`,'adresse') VALUES ('" + c.getIdCamp()+"','"+c.getNomCamp()+ "', '" + c.getNbrmax()+ "', '" + c.getNbrrefug()+ "','"+c.getAdresse()+"');";
        ste.executeUpdate(requeteInsert);
    }
    
   public void DeleteCamp (int idCamp) throws SQLException{
       String req= "DELETE from Camp where idCamp=?";
try {        
    PreparedStatement ste = cnx.prepareStatement(req) ;
    
    ste.setInt(1, idCamp);
    ste.executeUpdate();
     } catch (SQLException ex){
                
}
   }
public void updateCamp (Camp c, int id )
    {
    String req="UPDATE utilisateur SET nomCamp=?,nbrmax=?, nombreRef=?,addresse=? WHERE id =?" ; 
        try { 
            PreparedStatement ste = cnx.prepareStatement(req) ;
             
            ste.setString(1, c.getNomCamp());
            ste.setString(4, c.getAdresse());
            ste.setInt(2, c.getNbrmax());
            ste.setInt(3, c.getNbrrefug());           
            ste.executeUpdate() ; 
            
        } catch (SQLException ex) {
            
        }
    
    }
public List<Camp> getAll(){
        String req="SELECT * FROM camp" ;
        List<Camp> list = FXCollections.observableArrayList();
        try 
        { 
            PreparedStatement ste = cnx.prepareStatement(req) ;
            ResultSet rs = ste.executeQuery(); 
            while (rs.next())
            {
                int idCamp = rs.getInt(1);
                String nomCamp = rs.getString(2);
                String adresse = rs.getString(5);
                int nbrmax = rs.getInt(3);
                int nbrrefug = rs.getInt(4);
                list.add(new Camp(idCamp, nbrmax, nbrrefug, nomCamp, adresse));
            }

        } catch (SQLException ex) {
            
        }
        return null;
}
}
