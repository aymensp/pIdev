/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tunfugees.userentites;

/**
 *
 * @author USER
 */
public class Vars {
  
    public static int current_admin=0;
    public static int current_choice=0;
    public static Utilisateur current_user;
    
}
