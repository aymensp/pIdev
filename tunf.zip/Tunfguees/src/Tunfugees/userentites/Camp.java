
    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tunfugees.userentites;

/**
 *
 * @author AMINE
 */
public class Camp {

    private int idCamp,nbrmax,nbrrefug;
    private String nomCamp,adresse;

    public Camp(int idCamp, int nbrmax, int nbrrefug, String nomCamp, String adresse) {
        this.idCamp = idCamp;
        this.nbrmax = nbrmax;
        this.nbrrefug = nbrrefug;
        this.nomCamp = nomCamp;
        this.adresse = adresse;
    }

    public Camp(int i, String nom, int i0, int i1, String adresse) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getIdCamp() {
        return idCamp;
    }

    public void setIdCamp(int idCamp) {
        this.idCamp = idCamp;
    }

    public int getNbrmax() {
        return nbrmax;
    }

    public void setNbrmax(int nbrmax) {
        this.nbrmax = nbrmax;
    }

    public int getNbrrefug() {
        return nbrrefug;
    }

    public void setNbrrefug(int nbrrefug) {
        this.nbrrefug = nbrrefug;
    }

    public String getNomCamp() {
        return nomCamp;
    }

    public void setNomCamp(String nomCamp) {
        this.nomCamp = nomCamp;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    @Override
    public String toString() {
        return "Camp{" + "idCamp=" + idCamp + ", nbrmax=" + nbrmax + ", nbrrefug=" + nbrrefug + ", nomCamp=" + nomCamp + ", adresse=" + adresse + '}';
    }
    
    
    
}

    

