/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import Tunfugees.userentites.Camp;
import Tunfugees.userservices.ServiceCamp;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author AMINE
 */
public class AjoutCampController implements Initializable {

    @FXML
    private TextField TFid;
    @FXML
    private TextField TFnbmax;
    @FXML
    private TextField TFnbrref;
    @FXML
    private TextField TFnomcamp;
    @FXML
    private TextField TFadresse;
    @FXML
    private Button Btnajouter;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    @FXML
 private void AjouterCampAction(ActionEvent event) throws SQLException {
         String nom=TFnomcamp.getText();
        String adresse=TFadresse.getText();
       int id =Integer.parseInt(TFid.getText());
        
        int nbmax=Integer.parseInt(TFnbmax.getText());
        int nbrefuge=Integer.parseInt(TFnbrref.getText());

       
        ServiceCamp srv1 = new ServiceCamp();
        Camp c = new Camp (11,nom,44,40,adresse);
       
    }
    
}


