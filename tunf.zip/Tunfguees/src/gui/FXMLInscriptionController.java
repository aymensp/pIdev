/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.*;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import Tunfugees.userentites.Utilisateur;
import Tunfugees.userentites.Vars;
import Tunfugees.userservices.ServiceUser;


/**
 * FXML Controller class
 *
 * @author USER
 */
public class FXMLInscriptionController implements Initializable {
    
 private Connection cnx;    
@FXML private TextField nom;
@FXML private TextField prenom;
@FXML private TextField email;
@FXML private PasswordField password1;
@FXML private PasswordField password2;
@FXML private TextField age;
@FXML private TextField numero;
@FXML private TextField sexe;
@FXML private ChoiceBox<String> choix ;
@FXML private Button btinscription;

@FXML

// crée une fonction pour vérifier les champs vides  
    public boolean verifierchamps()
    {
        String fnom = nom.getText();
        String fprenom = prenom.getText();
        String femail = email.getText();
        String fpass1  = password1.getText();
        String fpass2  = password2.getText();
        String fage = age.getText ();
        String fnumero = numero.getText();
        String fsexe = sexe.getText();
        
        

                // vérifie les champs vides
                if (fnom.trim (). equals ("") || fprenom.trim (). equals ("") || femail.trim ().equals ("")
                   || fpass1.trim (). equals ("") || fpass2.trim (). equals ("") || fage.trim (). equals ("") || fnumero.trim (). equals ("")|| fsexe.trim().equals(""))
                {
                    JOptionPane.showMessageDialog (null, "Un ou plusieurs champs sont vides", "Champs vides", 2);
                    return false;
                }
                else if (!fpass1.equals(fpass2)) {
                    JOptionPane.showMessageDialog(null, "Mot de passe invalide");
                    return false;
                }

                 return true;
        }
        
        
        
        
    
    
    
    // valider inscription:
   public void  inscription ( ActionEvent event) throws SQLException, IOException {                                                 
         ServiceUser su = new ServiceUser();
         Utilisateur user = new Utilisateur();
     
         String fnom = nom.getText();
         String fprenom = prenom.getText();
         String femail = email.getText();
         String  fpass1= password1.getText();
         String  fpass2= password2.getText();
         String  fage= age.getText();
         String  fnumero= numero.getText();
         String fsexe= sexe.getText();
         
         
        
// vérifie si les données sont vides
         if (verifierchamps ())
         {
             user.setNom(fnom);
             user.setPrenom(fprenom);
             user.setEmail(femail);
             user.setPassword(fpass1);
             user.setAge(Integer.parseInt(fage));
             user.setNumero(Integer.parseInt(fnumero));
             user.setSexe(fsexe);
           if (choix.getValue().equals("utilisateur"))
                {
                    user.setRole("utilisateur");
                }
          if (choix.getValue().equals("administrareur"))
                {
                   user.setRole("administrareur"); 
                }
          
          
                 System.out.println(user.toString());
          
           
                 su.addUtilisateur(user);
                 
                 
         }        
         
         Parent tableview = FXMLLoader.load(getClass().getResource("/ListUtilisateur.fxml"));
    
    
   
        
        Scene sceneview = new Scene(tableview);
        
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(sceneview);
        window.show();
        
                   
    }                       
    

   

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    choix.getItems().add("utilisateur");
      choix.getItems().add("administrareur");
      
  
    }
    
    
}
