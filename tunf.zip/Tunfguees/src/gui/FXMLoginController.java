/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;
import Tunfugees.userentites.Utilisateur;
import Tunfugees.userservices.ServiceUser;
import Tunfugees.utile.ConnexionBD;
import java.sql.Connection;


/**
 * FXML Controller class
 *
 * @author USER
 */
public class FXMLoginController implements Initializable {
    
@FXML private TextField email;
@FXML private PasswordField password;    
@FXML private TextField btconnexion;
@FXML private TextField mdpOublier;


        
        
        String temail = email.getText ();
        String  tpassword = password.getText ();
        
        Connection con= ConnexionBD.getInstance().getCnx();
        public void buttonlogin( String cemail, String cpassword){

            
        // affiche un message si les champs nom d'utilisateur ou mot de passe sont vides
        if (temail.trim (). equals (""))
        {
            JOptionPane.showMessageDialog (null, "Entrez votre nom d'utilisateur", "Nom d'utilisateur vide", 2);
        }
        else if (tpassword.trim (). equals (""))
        {
            JOptionPane.showMessageDialog (null, "Entrez votre mot de passe", "Empty Password", 2);
        }
        try {
            
            String query = "SELECT * FROM` user` WHERE `email` =? AND` password` =? ";
            PreparedStatement ps= con.prepareStatement(query) ;
            ps.setString(1,cemail);
            ps.setString(2,cpassword);
            ps.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(ServiceUser.class.getName()).log(Level.SEVERE, null, ex);
        }
       
            
          
            
        }

   
        
        
        
  








    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
